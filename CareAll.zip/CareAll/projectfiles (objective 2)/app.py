
from projectfiles import database
from projectfiles.login import login
from projectfiles.menufunction import menu
from getpass import getpass
import bcrypt
import os
from time import sleep
clear = lambda: os.system('cls')



class Signup:
    all_rows=[]

    def __init__(self):
        pass

    def getusers(self,username):
        all_rows = database.cr.fetchall()
        database.cr.execute("select username from users\n")
        Signup.all_rows = database.cr.fetchall()
        for i in Signup.all_rows:
            if username==i[0]:
                return 1
        return 0


    def newUser(self):
        username=input("enter the username\n")

        ch=self.getusers(username)

        if ch==1:
            print("username already exist plz choose another username\n")
            self.newUser()
        else:
            category=-1
            creditcard=None
            balance=0
            print("enter password")
            password=getpass()

            hashed_password = bcrypt.hashpw(password.encode('utf-8'),bcrypt.gensalt())
            name=input("enter your full name\n")
            age=int(input("enter age\n"))
            if age <60:
                category=1

                print("----------------you are eligible to become caretaker----------------------")
            else:
                category=0
                print("----------------you are eligible to become  care needer----------------- ")
            phone=input("enter phone number\n")
            address=input("enter address\n")
            if category==0:
                creditcard=int(input("please enter first 4 digits of credit card number\n"))
                command="INSERT INTO users (username,name,password,age,category,phone,Address,fund,creditcard,islogged) VALUES (?,?,?,?,?,?,?,?,?,?)"
                database.cr.execute(command,(username,name,hashed_password,age,category,phone,address,0,creditcard,0))
            else:
                command = "INSERT INTO users (username,name,password,age,category,phone,Address,numberofelders,balance,islogged) VALUES (?,?,?,?,?,?,?,?,?,?)"
                database.cr.execute(command, (username, name,hashed_password, age, category, phone, address,0,balance,0))
            database.db.commit()

            print("user registered successfully")
            print("redirecting to main menu---------")
            sleep(3.0)
            clear()




    def displayMenu(self):
        lg=login()
        mf=menu()
        cmd="select username,islogged from users where islogged=?"
        database.cr.execute(cmd,(1,))
        user=database.cr.fetchall()
        cg=[1][0]
        if len(user)!=0:
            user=user[0][0]
            clear()
            mf.mainmenu(user,cg)
        else:

            print("------------------------CAREALL----------------------------")
            print("|                                                         |")
            print("|                                                         |")
            print("------------------------Welcome----------------------------")
            print()
            status=input("N---->signup\nY---->signin \n~---->exit\n")

            if status=='y' or status=='Y':
                ch,un=lg.loginfunction()
                if ch==1:
                    clear()
                    cmd='update users set islogged=? where username=?'
                    database.cr.execute(cmd,(1,un,))
                    database.db.commit()
                    print("login success redirecting---------------------------")
                    sleep(0.80)
                    clear()
                    mf.mainmenu(un,ch)

                else:
                    print("login failed plz enter correct username and password")
                    print("redirecting-----------------------------------------")
                    sleep(2.60)
                    clear()

                    self.displayMenu()


            elif status=='n' or status=='N':
                self.newUser()
            elif status=='~':
                database.db.close()
                exit()
            else:
                self.displayMenu()
        self.displayMenu()






nm=Signup()
nm.displayMenu()



