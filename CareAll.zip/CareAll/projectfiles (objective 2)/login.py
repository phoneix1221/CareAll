from projectfiles import database
from getpass import getpass
import bcrypt
import os
clear = lambda: os.system('cls')


class login:

    counterlog=-1
    Username=""

    def __init__(self):
        pass

    def loginfunction(self):
        ln=login()
        ln.Username=input("enter the username\n")
        password=getpass()
        command='select password from users where username=(?)'
        database.cr.execute(command,(ln.Username,))
        pas=database.cr.fetchall()
        if len(pas)==0:
            print("no user found by this username")
            return 0,'none'
        pas=pas[0]
        pas=pas[0]
        if bcrypt.checkpw(password.encode('utf-8'),pas) :
            login.counterlog=1
        else:
            login.counterlog=0
        return login.counterlog,ln.Username




