import sqlite3

db=sqlite3.connect('Users.db')
cr=db.cursor()
cr.execute("create table if not exists users(username TEXT NOT NULL  UNIQUE, name TEXT NOT NULL,  ID INTEGER PRIMARY KEY AUTOINCREMENT , password TEXT NOT NULL,"
           "age INTEGER NOT NULL,category BOOLEAN NOT NULL ,phone TEXT NOT NULL ,Address VARCHAR NOT NULL ,fund BIGINT ,numberofelders INT,creditcard INT  , balance BIGINT,islogged BOOLEAN NOT NULL )")
cr.execute("create table if not exists caretaker( id INTEGER NOT NULL ,username TEXT NOT NULL,unameofelder TEXT NOT NULL ,counter BOOLEAN NOT NULL, PRIMARY KEY(username,unameofelder)) ")
cr.execute("create table  if not exists review(reviewfor TEXT NOT NULL ,reviewby TEXT NOT NULL,rev TEXT ,rat Double, da date ,ti time , PRIMARY KEY(reviewfor,reviewby) )")
db.commit()





