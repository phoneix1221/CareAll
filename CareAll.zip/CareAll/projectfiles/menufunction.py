from projectfiles import database
from projectfiles.login import login
from time import sleep
import os
from datetime import date
import time
clear = lambda: os.system('cls')

class menu:

    # showlist ---> shows the list of the  users with their attributes  """

   def showlist(self,ls):
       c=1
       print("------------------------list----------------------------")
       print("NUMBER   Username        Name               Address         fund  ")
       for i in range(len(ls)):
           print(c,"     ",ls[i][0],"   ",ls[i][1],"   ",ls[i][2],"    ",ls[i][3])
           c+=1
       print("--------------------end of list-------------------------")


    #end of showlist

    # lt ---> shows the list of the  users   """

   def lt(self,ls):
       c=1
       print("------------------------list----------------------------")

       for i in range(len(ls)):
           print(c,"     ",ls[i][0])
           c+=1
       print("--------------------end of list-------------------------")


    #end of lt


   #show shows the username and welcome msg

   def show(self,uname):
       print("----------------------------------------------------")
       print("|                                                  |")
       print("|                 welcome ", uname, "              |")
       print("|                                                  |")
       print("----------------------------------------------------\n")

   #end of show

   #showrating shows the rating and reviews of users

   def showrating(self,ls,so,uname):
       c=1
       print("----------------------------------------------------")
       print("NUMBER      RATING GIVE TO-        RATING GIVEN BY -             REVIEW                           RATING          DATE  ")
       for i in range(len(ls)):
           print(c,"          ",ls[i][0],"               ",ls[i][1],"             ",ls[i][2],"                             ",ls[i][3],"   ",ls[i][4])
           c+=1
       z=input("press ~ to return to m ain menu")
       if z=='~':
           if so==1:
               self.young(uname)
           else:
               self.old(uname)

    #end of showrating




   #review process the review/rating of users

   def review(self,uname,so):
      z = (input("press @ to give rating\npress # to give review\npress ~ to return to main menu\n"))
      if so==1:
          command = 'select unameofelder from caretaker where username=? and counter=1'
      else:
          command = 'select username from caretaker where unameofelder=? and counter=1'
      database.cr.execute(command, (uname,))
      elders = database.cr.fetchall()
      self.lt(elders)
      if len(elders) != 0:
          k = int(input("enter the corresponding number you want to give review/rating \n"))
          revname = elders[k - 1][0]
          cmd = "insert or ignore into review(reviewfor,reviewby) VALUES(?,?) "
          database.cr.execute(cmd, (revname, uname))
          database.db.commit()
          if z == '#':
              review = input("type review here------------ max 50 characters\n ")
              da = date.today()
              ti = time.time()
              cmd = 'update review set rev=?,da=?,ti=? where reviewfor=? and reviewby=?'
              database.cr.execute(cmd, (review, da, ti, revname, uname))
              print("operation completed")
              database.db.commit()
          if z == '@':

              rating = float(input("type rating\n "))
              cmd = "update review set rat=? where reviewfor=? and reviewby=?"
              database.cr.execute(cmd, (rating, revname, uname,))
              print("operation completed")

              database.db.commit()

              if so == 1:
                  self.young(uname)
              else:
                  self.old(uname)

          else:
              print("redirecting to main menu")
              sleep(3.0)
              clear()
              if so==1:
                  self.young(uname)
              else:
                  self.old(uname)

      else:
          print("you havnt have any elder to rate or review")
          print("redirecting ---------")
          sleep(3.20)
          clear()
          if so == 1:
              self.young(uname)
          else:
              self.old(uname)



   #end of review


   #young processes all the function of caretakers

   def young(self,uname):
        self.show(uname)
        print("---------------------Menu---------------------------")
        ch=int(input("1--->search elders to take  care of them  and send them request  \n2--->view elders you are taking care of\n3--->revise elders you are taking care of\n4--->check balance\n5--->give rating/write/revise \n6--->view rating of elders\n7--->logout\n"))
        if ch==1:
            command='select username,name,address,fund from users where category=0 and username not in (select unameofelder from caretaker where username=? and counter=?)'
            database.cr.execute(command,(uname,1,))
            elders=database.cr.fetchall()
            cmd='select numberofelders from users where username=? '
            database.cr.execute(cmd,(uname,))
            numofelds=database.cr.fetchall()
            numofelds=numofelds[0][0]


            if len(elders)!=0:
                clear()
                self.showlist(elders)
                k=input("if you wanna choose elder  to take care of press @ \nif you want go to previous menu press ~ \n")
                if k=='@':
                    z=int(input("enter the corresponding number to select the elder\n"))
                    if numofelds>4:
                        print("limit exceeded you can only take care of 4 elders at a time\n")
                    else:
                        numofelds+=1
                        elderuname=elders[z-1][0]
                        cmd='select ID from users where username=?'
                        database.cr.execute(cmd,(uname,))
                        id=database.cr.fetchall()
                        id=id[0][0]
                        cmd='insert or ignore into caretaker(id,username,unameofelder,counter) Values(?,?,?,?)'
                        database.cr.execute(cmd,(id,uname,elderuname,0))
                        database.db.commit()
                        print("request send successful")
                        print("redirecting---- to main menu")
                        sleep(2.60)
                        clear()
                        self.young(uname)
                elif k=='~':
                    clear()
                    self.young(uname)
                else :
                    print("wrong choice")
                    clear()
                    self.young(uname)
            else:
                print("no elder left to take care of")
                print("redirecting------------------")
                sleep(3.0)
                clear()
                self.young(uname)


        elif ch==2:
            cmd='select unameofelder from caretaker where username=? and counter=1 '
            database.cr.execute(cmd,(uname,))
            eldlist=database.cr.fetchall()
            self.lt(eldlist)
            k = input("if you want go to previous menu press ~\n ")
            if k == '~':
                clear()
                self.young(uname)
            else:
                print("wrong choice")
                sleep(2.0)
                clear()
                self.young(uname)
        elif ch==3:
            cmd = 'select unameofelder from caretaker where username=? and counter=1'
            database.cr.execute(cmd, (uname,))
            eldlist = database.cr.fetchall()
            self.lt(eldlist)
            if len(eldlist)!=0:
                k=int(input("enter the corresponding number of elder you dont want to take care off anymore\n"))
                delelder=eldlist[k-1][0]
                cmd='delete from caretaker where unameofelder=? and counter=1'
                database.cr.execute(cmd, (delelder,))
                cmd = 'select numberofelders from users where username=? '
                database.cr.execute(cmd, (uname,))
                numofelds = database.cr.fetchall()
                numofelds = numofelds[0][0]
                numofelds-=1
                cmd = 'update users set numberofelders=? where username=?'
                database.cr.execute(cmd, (numofelds, uname))

                database.db.commit()
                print("returning to main menu---------")
                sleep(2.50)
            else:
                print("you are not taking care of any elder\n")

            k = input("if you want go to previous menu press ~ \n")
            if k == '~':
                clear()
                self.young(uname)
            else:
                print("wrong choice")
                sleep(2.50)
                clear()
                self.young(uname)

        elif ch==4:
            cmd='select balance from users where username=?'
            database.cr.execute(cmd,(uname,))
            balance=database.cr.fetchall()
            balance=balance[0][0]
            print("your balance is-\n",balance)
            q=input("enter ~ to return to main menu")
            if q=="~":
                clear()
                self.young(uname)
        elif ch==5:
            self.review(uname,1)

        elif ch==6:
            cmd='select reviewfor,reviewby,rev,rat,da from review where reviewfor in(select username from users where category=?) '
            zo=0
            database.cr.execute(cmd,(zo,))
            ls=database.cr.fetchall()
            self.showrating(ls,1,uname)

        elif ch==7:
            print("logging out please wait-------")
            cmd = 'update users set islogged=? where username=?'
            database.cr.execute(cmd, (0, uname,))
            database.db.commit()
            sleep(2.50)
            clear()
            return

 #end of young






 #old process all the functionalities of careneeders


   def old(self,uname):
      self.show(uname)
      print("---------------------Menu---------------------------")
      ch =int( input("1--->search  young people for  care taking \n2--->view all care taking requests \n3--->revise caretaker\n4--->allocate fund\n5--->give rating/write/revise \n6--->view rating of caretakers\n7--->logout\n"))
      if ch==1:
          command = 'select username,name,address,fund from users where category=1 and username not in (select username from caretaker where unameofelder=? and counter=?)'
          database.cr.execute(command,(uname,1,))
          youngers = database.cr.fetchall()

          if len(youngers) != 0:
              clear()
              self.showlist(youngers)
          else:
              print("there is no caretaker left")
          k = input("if you want go to previous menu press ~ \n")
          if k == '~':
              clear()
              self.old(uname)
          else:
              print("wrong choice")
              clear()
              self.old(uname)

      elif ch==2:
          command = 'select username from caretaker where unameofelder=? and counter=0'
          database.cr.execute(command,(uname,))
          youngers = database.cr.fetchall()
          if len(youngers) != 0:
              clear()
              self.lt(youngers)
              m=input("if you want to accept the request press @\nif you want to go back to main menu press ~ \n")
              if m=='@':
                  z=int(input("enter the corrosponding number to accept the request \n"))
                  youguname=youngers[z-1][0]
                  cmd='update  caretaker set counter=1 where username=? and unameofelder=?'
                  database.cr.execute(cmd, (youguname,uname))
                  cmd = 'select numberofelders from users where username=? '
                  database.cr.execute(cmd, (youguname,))
                  numofelds = database.cr.fetchall()
                  numofelds = numofelds[0][0]
                  numofelds+=1
                  cmd='update users set numberofelders=? where username=?'
                  database.cr.execute(cmd,(numofelds,youguname))
                  """balance update for young that is choosen"""
                  cmd='select fund from users where username=?'
                  database.cr.execute(cmd,(uname,))
                  fund=database.cr.fetchall()
                  fund=fund[0][0]
                  cmd='select balance from users where username=?'
                  database.cr.execute(cmd, (youguname,))
                  fu=database.cr.fetchall()
                  fu=fu[0][0]
                  fund=fu+fund
                  cmd='update users set balance=? where username=?'
                  database.cr.execute(cmd, (fund, youguname,))
                  database.db.commit()
                  print("request accepted---")
                  print("redirecting------------")
                  sleep(3.0)
                  clear()
                  self.old(uname)
              else:
                  print("no remaining request ")
                  print("redirecting------------")
                  sleep(3.0)
                  clear()
                  self.old(uname)
          else:
              print("no remaining request ")
              print("redirecting------------")
              sleep(3.0)
              clear()
              self.old(uname)



      elif ch==3:
          cmd='select username from caretaker where unameofelder=? and counter=1'
          database.cr.execute(cmd,(uname,))
          numofyoung=database.cr.fetchall()
          self.lt(numofyoung)
          if len(numofyoung)!=0:
              numofyoung=numofyoung[0][0]
              z=(input("do you wanna delete the current caretaker if yes press @\npress ~ to return to main menu\n"))
              if z=='@':
                cmd = 'delete from caretaker where unameofelder=? and counter=1 '
                database.cr.execute(cmd, (uname,))
                cmd = 'select numberofelders from users where username=? '
                database.cr.execute(cmd, (numofyoung,))
                numofelds = database.cr.fetchall()
                numofelds = numofelds[0][0]
                if numofelds!=0:
                        numofelds -=1
                cmd = 'update users set numberofelders=? where username=?'
                database.cr.execute(cmd, (numofelds,numofyoung,))
                database.db.commit()
                clear()
                self.old(uname)
              else:
                  print("redirecting------------")
                  sleep(3.0)
                  clear()
                  self.old(uname)
          else:
              print("no one is taking care of you")
              print("redirecting------------")
              sleep(3.0)
              clear()
              self.old(uname)


      elif ch==4:
            fu=int(input("enter the fund you want to allocate\n"))
            cmd='update users set fund=? where username=?'
            database.cr.execute(cmd, (fu,uname,))
            database.db.commit()
            print("allocation of fund is successful")
            print("redirecting to main menu")
            sleep(2.50)
            clear()
            self.old(uname)
      elif ch==5:
            self.review(uname,0)
      elif ch==6:
          cmd = 'select reviewfor,reviewby,rev,rat,da from review where reviewfor=(select username from users where category=?) '
          zo = 1
          database.cr.execute(cmd, (zo,))
          ls = database.cr.fetchall()
          self.showrating(ls,0,uname)

      elif ch==7:
          print("logging out please wait-------")
          cmd='update users set islogged=? where username=?'
          database.cr.execute(cmd,(0,uname,))
          database.db.commit()
          sleep(2.50)
          clear()
          return

   #end of old











 #check checks either a user is caretaker or careneeder


   def check(self,uname,ch):
       if ch==1:
           command='select category from users where username=?'
           database.cr.execute(command,(uname,))
           pas = database.cr.fetchall()
           pas = pas[0]
           pas = pas[0]

       return pas

    #end of check


  #mainmenu function is called by app

   def mainmenu(self,uname,ch):
       counter=self.check(uname,ch)
       if counter==1:
           self.young(uname)
       else:
           self.old(uname)
       return

   #end of mainemnu